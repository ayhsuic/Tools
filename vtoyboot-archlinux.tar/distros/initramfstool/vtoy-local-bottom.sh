#!/bin/sh
#************************************************************************************
# Copyright (c) 2020, longpanda <admin@ventoy.net>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <http://www.gnu.org/licenses/>.
#
#************************************************************************************

case $1 in
    prereqs)
       exit 0
       ;;
esac

if [ -f /tmp/vtoy_partuuid_links ]; then
    while read VTOY_PART_UUID_LINK VTOY_PART_UUID_TARGET; do
        if [ -L "$VTOY_PART_UUID_LINK" ] && [ "$(readlink "$VTOY_PART_UUID_LINK" 2>/dev/null)" = "$VTOY_PART_UUID_TARGET" ]; then
            rm -f "$VTOY_PART_UUID_LINK"
        fi
    done < /tmp/vtoy_partuuid_links

    rm -f /tmp/vtoy_partuuid_links
fi

